import java.util.List;
import java.util.Scanner;

public class Main {
    private static AgendamentoDAO agendamentoDAO = new AgendamentoDAO();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            System.out.println("1. Adicionar Agendamento");
            System.out.println("2. Exibir Agendamentos");
            System.out.println("3. Cancelar Agendamento");
            System.out.println("4. Sair");
            System.out.print("Escolha uma opção: ");

            int opcao = scanner.nextInt();
            scanner.nextLine();  // consumir nova linha

            switch (opcao) {
                case 1:
                    adicionarAgendamento();
                    break;
                case 2:
                    exibirAgendamentos();
                    break;
                case 3:
                    cancelarAgendamento();
                    break;
                case 4:
                    System.exit(0);
                default:
                    System.out.println("Opção inválida");
            }
        }
    }

    private static void adicionarAgendamento() {
        System.out.print("Tutor: ");
        String tutor = scanner.nextLine();
        System.out.print("Data (YYYY-MM-DD): ");
        String data = scanner.nextLine();
        System.out.print("Horário (HH:MM:SS): ");
        String horario = scanner.nextLine();
        System.out.print("Pet: ");
        String pet = scanner.nextLine();
        System.out.print("Tipo de Atendimento: ");
        String tipoAtendimento = scanner.nextLine();
        System.out.print("Status: ");
        String status = scanner.nextLine();

        Agendamento agendamento = new Agendamento();
        agendamento.setTutor(tutor);
        agendamento.setData(data);
        agendamento.setHorario(horario);
        agendamento.setPet(pet);
        agendamento.setTipoAtendimento(tipoAtendimento);
        agendamento.setStatus(status);

        agendamentoDAO.salvarAgendamento(agendamento);
        System.out.println("Agendamento adicionado com sucesso!");
    }

    private static void exibirAgendamentos() {
        List<Agendamento> agendamentos = agendamentoDAO.carregarAgendamentos();

        for (Agendamento agendamento : agendamentos) {
            System.out.println("ID: " + agendamento.getId() +
                    ", Tutor: " + agendamento.getTutor() +
                    ", Data: " + agendamento.getData() +
                    ", Horário: " + agendamento.getHorario() +
                    ", Pet: " + agendamento.getPet() +
                    ", Tipo de Atendimento: " + agendamento.getTipoAtendimento() +
                    ", Status: " + agendamento.getStatus());
        }
    }

    private static void cancelarAgendamento() {
        System.out.print("ID do agendamento a ser cancelado: ");
        int id = scanner.nextInt();
        agendamentoDAO.cancelarAgendamento(id);
        System.out.println("Agendamento cancelado com sucesso!");
    }
}