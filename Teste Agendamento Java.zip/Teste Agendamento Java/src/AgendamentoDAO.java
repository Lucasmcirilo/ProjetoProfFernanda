import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AgendamentoDAO {

    public void salvarAgendamento(Agendamento agendamento) {
        String sql = "INSERT INTO agendamentos (tutor, data, horario, pet, tipo_atendimento, status) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, agendamento.getTutor());
            stmt.setString(2, agendamento.getData());
            stmt.setString(3, agendamento.getHorario());
            stmt.setString(4, agendamento.getPet());
            stmt.setString(5, agendamento.getTipoAtendimento());
            stmt.setString(6, agendamento.getStatus());

            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Agendamento> carregarAgendamentos() {
        List<Agendamento> agendamentos = new ArrayList<>();
        String sql = "SELECT * FROM agendamentos";

        try (Connection conn = Conexao.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Agendamento agendamento = new Agendamento();
                agendamento.setId(rs.getInt("id"));
                agendamento.setTutor(rs.getString("tutor"));
                agendamento.setData(rs.getString("data"));
                agendamento.setHorario(rs.getString("horario"));
                agendamento.setPet(rs.getString("pet"));
                agendamento.setTipoAtendimento(rs.getString("tipo_atendimento"));
                agendamento.setStatus(rs.getString("status"));
                agendamentos.add(agendamento);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return agendamentos;
    }

    public void cancelarAgendamento(int id) {
        String sql = "DELETE FROM agendamentos WHERE id = ?";

        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}